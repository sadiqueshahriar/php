module.exports = {
    "extends": "standard",
    "plugins": [
        "standard"
    ]
};