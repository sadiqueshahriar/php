# Ecommerce-Cart
A Ecommerce Shopping Cart using PHP Sessions &amp; Ajax

How To Use/Run This Code :-
1. Download Project and Extract Files
2. Install XAMPP OR WAMP Web Server on Your System
3. XAMPP - Move Ecommerce-Cart-master Folder On " c:/xampp/htdocs/ " Or WAMP - Move Your Files On " c:/wamp/www/ "
3. Open Your Web Browser And Type "localhost/phpmyadmin" Or "127.0.0.1/phpmyadmin"
4. Then Click import Button & import Database(anonymous.sql)
5. Open Your Web Browser And Type "localhost/Ecommerce-Cart-master/index.php" or "127.0.0.1/Ecommerce-Cart-master/index.php"
6. Enjoy  ☺☺☺☺

Watch On Youtube :- https://youtu.be/OpE1eXQ8p74

![add-to-cart](https://user-images.githubusercontent.com/26626045/53680445-8d97be00-3c90-11e9-8c5b-d2784b1ca6e0.jpg)

Example :- 

![cart-select](https://user-images.githubusercontent.com/26626045/53684297-60fb9a80-3cc0-11e9-9a2b-424f5ee925e2.PNG)

My Cart :-

![my-cart](https://user-images.githubusercontent.com/26626045/53684296-60fb9a80-3cc0-11e9-9179-54e86115da8f.PNG)
